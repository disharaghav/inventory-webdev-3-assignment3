const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Name is required'], trim: true, minlength: 2, maxlength: 100 },
    sku: {
      type: String, required: [true, 'SKU is required'], unique: true, uppercase: true, trim: true,
      match: [/^[A-Z0-9-]{3,20}$/, 'SKU must be 3-20 chars: letters, digits, hyphen']
    },
    description: { type: String, trim: true, maxlength: 500 },
    category: { type: String, required: [true, 'Category is required'], trim: true, lowercase: true, index: true },
    price: { type: Number, required: [true, 'Price is required'], min: [0, 'Price cannot be negative'] },
    quantity: {
      type: Number, default: 0, min: [0, 'Quantity cannot be negative'],
      validate: { validator: Number.isInteger, message: 'Quantity must be an integer' }
    },
    reorderLevel: { type: Number, default: 10, min: 0 },
    supplier: { type: String, trim: true },
    isActive: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Product', productSchema);
