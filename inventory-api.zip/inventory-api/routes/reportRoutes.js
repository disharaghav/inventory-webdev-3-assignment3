const router = require('express').Router();
const c = require('../controllers/productController');

router.get('/summary', c.summaryReport);
router.get('/by-category', c.categoryReport);
router.get('/low-stock', c.lowStockReport);

module.exports = router;
