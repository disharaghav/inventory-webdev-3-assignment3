const router = require('express').Router();
const c = require('../controllers/productController');
const { validateId, validateQuantity } = require('../middleware/validate');

router.route('/').get(c.getProducts).post(c.createProduct);
router.route('/:id').all(validateId).get(c.getProduct).put(c.updateProduct).delete(c.deleteProduct);
router.patch('/:id/restock', validateId, validateQuantity, c.restock);
router.patch('/:id/sale', validateId, validateQuantity, c.sell);

module.exports = router;
