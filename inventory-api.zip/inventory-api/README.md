# Inventory and Data Management System

Setup: `npm install`, copy `.env.example` to `.env`, then `npm start`.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | /api/products | Create product |
| GET | /api/products | List (category, search, minPrice, maxPrice, inStock, sort, page, limit) |
| GET/PUT/DELETE | /api/products/:id | Read / update / delete |
| PATCH | /api/products/:id/restock | Body `{"quantity": n}` increments stock |
| PATCH | /api/products/:id/sale | Body `{"quantity": n}` atomically decrements stock |
| GET | /api/reports/summary | Totals and inventory value |
| GET | /api/reports/by-category | Per-category aggregation |
| GET | /api/reports/low-stock | Items at or below reorder level |

Example: `GET /api/products?category=electronics&minPrice=100&sort=-price&page=1&limit=5`
