const Product = require('../models/Product');
const { asyncHandler, httpError } = require('../middleware/validate');

const SORT_FIELDS = ['name', 'price', 'quantity', 'category', 'createdAt'];
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

exports.createProduct = asyncHandler(async (req, res) => {
  const product = await Product.create(req.body);
  res.status(201).json({ success: true, data: product });
});

exports.getProducts = asyncHandler(async (req, res) => {
  const { category, search, minPrice, maxPrice, inStock, sort = '-createdAt' } = req.query;
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit) || 10, 1), 100);

  const filter = { isActive: true };
  if (category) filter.category = category.toLowerCase();
  if (search) {
    const rx = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ name: rx }, { sku: rx }, { description: rx }];
  }
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = Number(minPrice);
    if (maxPrice) filter.price.$lte = Number(maxPrice);
  }
  if (inStock === 'true') filter.quantity = { $gt: 0 };
  if (inStock === 'false') filter.quantity = 0;

  const sortBy = sort.split(',').filter((f) => SORT_FIELDS.includes(f.replace('-', ''))).join(' ') || '-createdAt';

  const [data, total] = await Promise.all([
    Product.find(filter).sort(sortBy).skip((page - 1) * limit).limit(limit),
    Product.countDocuments(filter)
  ]);

  res.json({ success: true, total, page, pages: Math.ceil(total / limit), count: data.length, data });
});

exports.getProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) throw httpError(404, 'Product not found');
  res.json({ success: true, data: product });
});

exports.updateProduct = asyncHandler(async (req, res) => {
  const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!product) throw httpError(404, 'Product not found');
  res.json({ success: true, data: product });
});

exports.deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findByIdAndDelete(req.params.id);
  if (!product) throw httpError(404, 'Product not found');
  res.json({ success: true, message: 'Product deleted' });
});

exports.restock = asyncHandler(async (req, res) => {
  const product = await Product.findByIdAndUpdate(
    req.params.id, { $inc: { quantity: req.body.quantity } }, { new: true }
  );
  if (!product) throw httpError(404, 'Product not found');
  res.json({ success: true, data: product });
});

exports.sell = asyncHandler(async (req, res) => {
  const { quantity } = req.body;
  const product = await Product.findOneAndUpdate(
    { _id: req.params.id, quantity: { $gte: quantity } },
    { $inc: { quantity: -quantity } },
    { new: true }
  );
  if (!product) {
    if (!(await Product.exists({ _id: req.params.id }))) throw httpError(404, 'Product not found');
    throw httpError(400, 'Insufficient stock');
  }
  res.json({ success: true, data: product });
});

exports.summaryReport = asyncHandler(async (req, res) => {
  const [summary] = await Product.aggregate([
    { $match: { isActive: true } },
    {
      $group: {
        _id: null,
        totalProducts: { $sum: 1 },
        totalUnits: { $sum: '$quantity' },
        totalValue: { $sum: { $multiply: ['$price', '$quantity'] } },
        avgPrice: { $avg: '$price' },
        outOfStock: { $sum: { $cond: [{ $eq: ['$quantity', 0] }, 1, 0] } }
      }
    },
    { $project: { _id: 0 } }
  ]);
  res.json({ success: true, data: summary || { totalProducts: 0, totalUnits: 0, totalValue: 0, avgPrice: 0, outOfStock: 0 } });
});

exports.categoryReport = asyncHandler(async (req, res) => {
  const data = await Product.aggregate([
    { $match: { isActive: true } },
    {
      $group: {
        _id: '$category',
        products: { $sum: 1 },
        totalUnits: { $sum: '$quantity' },
        totalValue: { $sum: { $multiply: ['$price', '$quantity'] } },
        avgPrice: { $avg: '$price' }
      }
    },
    { $sort: { totalValue: -1 } },
    { $project: { _id: 0, category: '$_id', products: 1, totalUnits: 1, totalValue: 1, avgPrice: { $round: ['$avgPrice', 2] } } }
  ]);
  res.json({ success: true, data });
});

exports.lowStockReport = asyncHandler(async (req, res) => {
  const data = await Product.aggregate([
    { $match: { isActive: true, $expr: { $lte: ['$quantity', '$reorderLevel'] } } },
    { $project: { name: 1, sku: 1, category: 1, quantity: 1, reorderLevel: 1, shortfall: { $subtract: ['$reorderLevel', '$quantity'] } } },
    { $sort: { shortfall: -1 } }
  ]);
  res.json({ success: true, count: data.length, data });
});
