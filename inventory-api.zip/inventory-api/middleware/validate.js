const mongoose = require('mongoose');

const httpError = (status, message) => Object.assign(new Error(message), { status });

const validateId = (req, res, next) =>
  mongoose.isValidObjectId(req.params.id) ? next() : next(httpError(400, 'Invalid product id'));

const validateQuantity = (req, res, next) => {
  const q = req.body.quantity;
  if (!Number.isInteger(q) || q <= 0) return next(httpError(400, 'quantity must be a positive integer'));
  next();
};

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { validateId, validateQuantity, asyncHandler, httpError };
